# Requirement Gathering + Admin Dashboard

Struktur:
- `/index.html` = form client
- `/admin/login.html` = login admin Supabase Auth
- `/admin/dashboard.html` = dashboard, search, filter, detail, update status
- `/admin.sql` = RLS policies Supabase

## Setup
1. Upload `admin/` ke repository di folder `admin/`.
2. Upload `admin.sql` ke repository atau buka file dan copy SQL ke Supabase SQL Editor.
3. Di Supabase Authentication → Users, buat user admin dengan email/password.
4. Pastikan tabel `requirement_submissions` memiliki kolom yang dipakai form dan kolom `status`, `created_at`, serta primary key `id`.
5. Buka `/admin/login.html`.
6. Login dengan akun admin Supabase.

Catatan keamanan:
- Publishable key boleh berada di frontend.
- Jangan pernah menaruh `service_role` atau secret key di HTML.
- RLS wajib aktif seperti SQL yang disediakan.
