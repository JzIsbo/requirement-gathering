-- Jalankan di Supabase SQL Editor.
-- Pastikan tabel requirement_submissions sudah ada.

-- 1) Aktifkan RLS.
alter table public.requirement_submissions enable row level security;

-- 2) Client boleh INSERT tanpa login.
drop policy if exists "public can submit requirements" on public.requirement_submissions;
create policy "public can submit requirements"
on public.requirement_submissions
for insert
to anon
with check (true);

-- 3) Admin yang login boleh membaca data.
drop policy if exists "authenticated can read requirements" on public.requirement_submissions;
create policy "authenticated can read requirements"
on public.requirement_submissions
for select
to authenticated
using (true);

-- 4) Admin yang login boleh mengubah status.
drop policy if exists "authenticated can update requirements" on public.requirement_submissions;
create policy "authenticated can update requirements"
on public.requirement_submissions
for update
to authenticated
using (true)
with check (true);

-- 5) Jangan izinkan anon membaca/mengubah data.
revoke select, update, delete on public.requirement_submissions from anon;
grant insert on public.requirement_submissions to anon;
grant select, update on public.requirement_submissions to authenticated;
